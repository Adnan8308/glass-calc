# Glass Calc (Android, Jetpack Compose)

Open this folder in Android Studio (Koala or newer), let Gradle sync, run on a device.

- Liquid glass slider needs **Android 13+ (API 33)** for the AGSL refraction shader. Older phones get a plain frosted thumb.
- Press and hold the thumb: it lifts and grows (deeper refraction, bigger shadow). Drag left/right, release to snap.
- Top-right button toggles dark mode. Tap a history item to reuse its result.

Shader: `LiquidGlass.kt` (`GLASS_AGSL`). Tune `strength`, `disp`, `tint` there.
