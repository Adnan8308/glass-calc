package com.example.glasscalc

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.ui.util.lerp as lerpF

val LocalDark = compositionLocalOf { 0f }

@Composable
fun ink(): Color = lerp(Color(0xFF14172B), Color.White, LocalDark.current)

/** Static "frosted" glass surface used for keys, cards and buttons. */
fun Modifier.glassSurface(shape: Shape, tint: Color = Color.Transparent): Modifier = composed {
    val d = LocalDark.current
    this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(
                    Color.White.copy(alpha = lerpF(0.42f, 0.18f, d)),
                    Color.White.copy(alpha = lerpF(0.14f, 0.05f, d)),
                )
            )
        )
        .background(tint)
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(0.95f), Color.White.copy(0.12f), Color.White.copy(0.5f))),
            shape,
        )
}

@Composable
fun GlassCalcApp() {
    var dark by rememberSaveable { mutableStateOf(false) }
    val darkState = animateFloatAsState(if (dark) 1f else 0f, tween(550), label = "dark")
    val darkF = darkState.value
    val slider = remember { GlassSliderState() }
    val shader = remember { createGlassShader() }
    val calc = remember { CalcState() }
    val scope = rememberCoroutineScope()

    val view = LocalView.current
    SideEffect {
        val w = (view.context as? android.app.Activity)?.window
        if (w != null) WindowCompat.getInsetsController(w, view).isAppearanceLightStatusBars = !dark
    }

    CompositionLocalProvider(LocalDark provides darkF) {
        Box(Modifier.fillMaxSize().glassLens(shader, slider, darkState)) {
            AuroraBackground()
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp)) {
                TopBar(
                    title = if (slider.selected == 0) "Calculator" else "History",
                    dark = dark,
                    onToggle = { dark = !dark },
                )
                Box(Modifier.weight(1f).padding(top = 8.dp)) {
                    Crossfade(targetState = slider.selected, animationSpec = tween(220), label = "page") { page ->
                        if (page == 0) CalculatorScreen(calc)
                        else HistoryScreen(calc) { item ->
                            calc.load(item.result)
                            scope.launch { slider.progress.animateTo(0f, spring(0.72f, 380f)) }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                GlassTabBar(slider, listOf("Calculator", "History"), hasShader = shader != null, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun TopBar(title: String, dark: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(56.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = ink(), modifier = Modifier.weight(1f))
        val src = remember { MutableInteractionSource() }
        val pressed by src.collectIsPressedAsState()
        val scale by animateFloatAsState(if (pressed) 0.9f else 1f, spring(0.5f, 500f), label = "s")
        Box(
            Modifier
                .size(48.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .glassSurface(CircleShape)
                .clickable(src, null, onClick = onToggle),
            contentAlignment = Alignment.Center,
        ) {
            val c = ink()
            Canvas(Modifier.size(24.dp)) {
                val r = size.minDimension * 0.26f
                val ctr = center
                if (dark) {
                    // sun
                    drawCircle(c, r, ctr)
                    for (i in 0 until 8) {
                        val a = i * PI / 4
                        val s = Offset(ctr.x + cos(a).toFloat() * r * 1.5f, ctr.y + sin(a).toFloat() * r * 1.5f)
                        val e = Offset(ctr.x + cos(a).toFloat() * r * 2.0f, ctr.y + sin(a).toFloat() * r * 2.0f)
                        drawLine(c, s, e, strokeWidth = 2.2f * density, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    }
                } else {
                    // moon (crescent)
                    val big = Path().apply { addOval(androidx.compose.ui.geometry.Rect(ctr, size.minDimension * 0.42f)) }
                    val cut = Path().apply {
                        addOval(androidx.compose.ui.geometry.Rect(Offset(ctr.x + r * 0.9f, ctr.y - r * 0.7f), size.minDimension * 0.36f))
                    }
                    val moon = Path.combine(PathOperation.Difference, big, cut)
                    drawPath(moon, c)
                }
            }
        }
    }
}

@Composable
fun AuroraBackground() {
    val d = LocalDark.current
    val t by rememberInfiniteTransition(label = "aurora").animateFloat(
        0f, 1f, infiniteRepeatable(tween(26000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val top = lerp(Color(0xFFD6E4FF), Color(0xFF070A1C), d)
    val bottom = lerp(Color(0xFFF9E1F2), Color(0xFF140B28), d)
    val blobs = listOf(
        lerp(Color(0xFF6FA2FF), Color(0xFF3257FF), d),
        lerp(Color(0xFFFF8FC4), Color(0xFFA32BFF), d),
        lerp(Color(0xFF8CF5D2), Color(0xFF00BFB3), d),
        lerp(Color(0xFFFFCF7A), Color(0xFFFF3D8B), d),
    )
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(top, bottom)))
        val w = size.width
        val h = size.height
        val a = (t * 2 * PI).toFloat()
        val spots = listOf(
            Offset(w * (0.2f + 0.15f * sin(a)), h * (0.18f + 0.06f * cos(a))),
            Offset(w * (0.85f + 0.08f * cos(a * 1f)), h * (0.38f + 0.08f * sin(a))),
            Offset(w * (0.25f + 0.1f * cos(a)), h * (0.62f + 0.07f * sin(a))),
            Offset(w * (0.78f + 0.1f * sin(a)), h * (0.85f + 0.05f * cos(a))),
        )
        spots.forEachIndexed { i, o ->
            val r = w * (0.55f + 0.05f * i)
            drawCircle(
                Brush.radialGradient(
                    listOf(blobs[i].copy(alpha = lerpF(0.85f, 0.65f, d)), blobs[i].copy(alpha = 0f)),
                    center = o, radius = r,
                ),
                radius = r, center = o,
            )
        }
    }
}

@Composable
fun CalculatorScreen(calc: CalcState) {
    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.End,
        ) {
            Text(
                calc.expr.ifEmpty { " " },
                fontSize = 28.sp, color = ink().copy(alpha = 0.6f),
                textAlign = TextAlign.End, maxLines = 2,
            )
            val r = calc.result.ifEmpty { "0" }
            Text(
                r,
                fontSize = when { r.length > 14 -> 34.sp; r.length > 10 -> 44.sp; r.length > 7 -> 56.sp; else -> 72.sp },
                fontWeight = FontWeight.Light, color = ink(), maxLines = 1,
            )
        }
        Spacer(Modifier.height(8.dp))
        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "="),
        )
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            rows.forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { k ->
                        val wide = k == "0"
                        GlassKey(
                            label = k,
                            modifier = Modifier
                                .weight(if (wide) 2f else 1f)
                                .aspectRatio(if (wide) 2.16f else 1f),
                        ) { calc.input(k) }
                    }
                }
            }
        }
    }
}

@Composable
fun GlassKey(label: String, modifier: Modifier, onClick: () -> Unit) {
    val isOp = label in listOf("÷", "×", "−", "+")
    val isEq = label == "="
    val isFn = label in listOf("AC", "⌫", "%")
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.92f else 1f, spring(0.5f, 500f), label = "k")
    val tint = when {
        isEq -> Color(0xFFFF9F0A).copy(alpha = 0.60f)
        isOp -> Color(0xFF5B8CFF).copy(alpha = 0.28f)
        isFn -> Color.White.copy(alpha = 0.10f)
        else -> Color.Transparent
    }
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .glassSurface(CircleShape, tint)
            .clickable(src, null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = if (isOp || isEq) 32.sp else 28.sp,
            fontWeight = if (isOp || isEq) FontWeight.Medium else FontWeight.Normal,
            color = if (isEq) Color.White else ink(),
        )
    }
}

@Composable
fun HistoryScreen(calc: CalcState, onPick: (HistoryItem) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        if (calc.history.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No calculations yet", fontSize = 18.sp, color = ink().copy(alpha = 0.55f))
            }
        } else {
            Box(
                Modifier
                    .align(Alignment.End)
                    .height(40.dp)
                    .glassSurface(RoundedCornerShape(50))
                    .clickable { calc.clearHistory() }
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center,
            ) { Text("Clear", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = ink()) }
            Spacer(Modifier.height(10.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(calc.history) { item ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .glassSurface(RoundedCornerShape(24.dp))
                            .clickable { onPick(item) }
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalAlignment = Alignment.End,
                    ) {
                        Text(item.expr, fontSize = 18.sp, color = ink().copy(alpha = 0.6f), maxLines = 1)
                        Text("= ${item.result}", fontSize = 30.sp, fontWeight = FontWeight.Light, color = ink(), maxLines = 1)
                    }
                }
            }
        }
    }
}
