package com.example.glasscalc

import android.annotation.SuppressLint
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import androidx.compose.ui.util.lerp as lerpF
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Liquid glass lens, written in AGSL (Android 13+).
 *
 * It is a rounded-rect lens (signed distance field) that is applied on top of the WHOLE screen layer,
 * so it refracts whatever is really underneath it: labels, keys, the aurora background.
 *  - edge refraction : sample position is bent along the SDF normal, strongest at the rim
 *  - magnification   : slight zoom towards the centre, like a thick glass drop
 *  - dispersion      : R/G/B sampled with different offsets (chromatic aberration)
 *  - soft frosting   : small 5-tap blur
 *  - fresnel rim     : bright thin edge, brighter on the light side, softer on the opposite side
 *  - specular        : glossy highlight blob near the top
 *  - depth shadow    : soft drop shadow that grows when the lens is pressed
 */
const val GLASS_AGSL = """
uniform shader content;
uniform float2 center;
uniform float2 halfSize;
uniform float radius;
uniform float press;
uniform float dark;

float sdBox(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + r;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - r;
}

half4 main(float2 frag) {
    float2 p = frag - center;
    float d = sdBox(p, halfSize, radius);
    half4 base = content.eval(frag);

    // ---- outside the lens: soft depth shadow ----
    float reach = 26.0 + 22.0 * press;
    float dd = max(d, 0.0);
    float s = clamp(1.0 - dd / reach, 0.0, 1.0);
    float shadow = s * s * (0.10 + 0.20 * press);
    half3 outside = base.rgb * (1.0 - shadow);
    if (d > 1.0) return half4(outside, 1.0);

    // ---- inside the lens ----
    float depth = max(-d, 0.0);
    float minDim = min(halfSize.x, halfSize.y);
    float e = clamp(1.0 - depth / (minDim * 0.9), 0.0, 1.0);

    float2 ex = float2(1.0, 0.0);
    float2 ey = float2(0.0, 1.0);
    float2 g = float2(
        sdBox(p + ex, halfSize, radius) - sdBox(p - ex, halfSize, radius),
        sdBox(p + ey, halfSize, radius) - sdBox(p - ey, halfSize, radius));
    float2 n = g / (length(g) + 1e-4);

    float bend = e * e * e;
    float strength = minDim * (0.65 + 0.35 * press);
    float2 uv = frag - n * bend * strength - p * (0.10 + 0.10 * press);

    float2 disp = n * bend * minDim * (0.10 + 0.12 * press);
    half3 col;
    col.r = content.eval(uv + disp).r;
    col.g = content.eval(uv).g;
    col.b = content.eval(uv - disp).b;

    float k = 2.5 + 2.0 * press;
    half3 blur = content.eval(uv + float2(k, k)).rgb
               + content.eval(uv + float2(-k, k)).rgb
               + content.eval(uv + float2(k, -k)).rgb
               + content.eval(uv + float2(-k, -k)).rgb;
    col = (col * 2.0 + blur) / 6.0;

    // glass body tint
    float vy = clamp(p.y / halfSize.y * 0.5 + 0.5, 0.0, 1.0);
    float tint = mix(0.16, 0.05, dark);
    col = mix(col, half3(1.0), tint * (1.0 - 0.5 * vy));
    col *= 1.0 - 0.06 * vy * (1.0 - dark);

    // rim light (fresnel)
    float2 L = normalize(float2(-0.55, -0.85));
    float facing = dot(n, L);
    float rim = 1.0 - smoothstep(0.0, 3.2, depth);
    float rimLight = rim * (0.30 + 0.70 * max(facing, 0.0));
    float rimBack = rim * max(-facing, 0.0) * 0.40;
    float glow = (1.0 - smoothstep(0.0, 16.0, depth)) * 0.10 * (0.5 + 0.5 * facing);
    col += half3(rimLight + rimBack + glow);

    // inner dark line right at the edge gives thickness
    float inner = (1.0 - smoothstep(3.0, 6.0, depth)) * smoothstep(1.0, 3.0, depth) * 0.06;
    col -= half3(inner);

    // specular highlight
    float2 sp = (p - float2(-halfSize.x * 0.30, -halfSize.y * 0.52)) / float2(halfSize.x * 0.55, halfSize.y * 0.26);
    float spec = exp(-dot(sp, sp)) * (0.30 + 0.15 * press);
    col += half3(spec);

    // smooth silhouette against the shadowed outside
    float a = clamp(1.0 - d, 0.0, 1.0);
    half3 outRgb = mix(outside, col, a);
    return half4(clamp(outRgb, 0.0, 1.0), 1.0);
}
"""

class GlassSliderState {
    val progress = Animatable(0f)   // 0 = Calculator, 1 = History
    val press = Animatable(0f)      // 0 = resting, 1 = pressed (lifted, deeper refraction)
    var bar by mutableStateOf(Rect.Zero)
    val selected: Int get() = if (progress.value > 0.5f) 1 else 0
}

@SuppressLint("NewApi")
fun createGlassShader(): RuntimeShader? =
    if (Build.VERSION.SDK_INT >= 33) RuntimeShader(GLASS_AGSL) else null

private val BarPad = 6.dp

/** Applies the lens to everything inside this composable (use on the root). */
@SuppressLint("NewApi")
fun Modifier.glassLens(shader: RuntimeShader?, st: GlassSliderState, dark: State<Float>): Modifier =
    if (shader == null) this else this.graphicsLayer {
        val bar = st.bar
        if (bar.width > 0f) {
            val pad = BarPad.toPx()
            val thumbW = (bar.width - 2 * pad) / 2f
            val halfH0 = (bar.height - 2 * pad) / 2f
            val press = st.press.value
            val hw = thumbW / 2f * (1f + 0.10f * press)
            val hh = halfH0 * (1f + 0.34f * press)
            val cx = bar.left + pad + thumbW / 2f + st.progress.value * thumbW
            val cy = bar.center.y - 3.dp.toPx() * press
            shader.setFloatUniform("center", cx, cy)
            shader.setFloatUniform("halfSize", hw, hh)
            shader.setFloatUniform("radius", hh)
            shader.setFloatUniform("press", press)
        } else {
            shader.setFloatUniform("center", -10000f, -10000f)
            shader.setFloatUniform("halfSize", 1f, 1f)
            shader.setFloatUniform("radius", 1f)
            shader.setFloatUniform("press", 0f)
        }
        shader.setFloatUniform("dark", dark.value)
        renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
        clip = false
    }

/** The pill-shaped bar with the two labels. The glass thumb itself is drawn by the shader. */
@Composable
fun GlassTabBar(
    state: GlassSliderState,
    labels: List<String>,
    hasShader: Boolean,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val shape = RoundedCornerShape(50)
    val darkF = LocalDark.current
    val density = LocalDensity.current

    Box(
        modifier
            .height(68.dp)
            .onGloballyPositioned { state.bar = it.boundsInRoot() }
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = lerpF(0.30f, 0.12f, darkF)),
                        Color.White.copy(alpha = lerpF(0.12f, 0.05f, darkF)),
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White.copy(0.85f), Color.White.copy(0.12f), Color.White.copy(0.45f))),
                shape,
            )
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val pad = with(density) { BarPad.toPx() }
                    val thumbW = (size.width - 2 * pad) / 2f
                    val startX = down.position.x
                    val thumbLeft = pad + state.progress.value * thumbW
                    val onThumb = startX in thumbLeft..(thumbLeft + thumbW)

                    scope.launch { state.press.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 420f)) }

                    var pos = state.progress.value
                    var moved = false
                    drag(down.id) { change ->
                        val dx = change.positionChange().x
                        if (abs(change.position.x - startX) > viewConfiguration.touchSlop) moved = true
                        pos = (pos + dx / thumbW).coerceIn(0f, 1f)
                        val p = pos
                        scope.launch { state.progress.snapTo(p) }
                        change.consume()
                    }

                    val target = when {
                        moved || onThumb -> if (pos > 0.5f) 1f else 0f
                        else -> if (startX > size.width / 2f) 1f else 0f
                    }
                    scope.launch {
                        launch { state.press.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 260f)) }
                        state.progress.animateTo(target, spring(dampingRatio = 0.72f, stiffness = 380f))
                    }
                }
            }
    ) {
        if (!hasShader) {
            // Fallback for Android < 13: plain translucent thumb
            val thumbWdp = with(density) { ((state.bar.width - 2 * BarPad.toPx()) / 2f).toDp() }
            val offsetPx = with(density) { BarPad.toPx() + state.progress.value * (state.bar.width - 2 * BarPad.toPx()) / 2f }
            Box(
                Modifier
                    .offset { IntOffset(offsetPx.roundToInt(), with(density) { BarPad.roundToPx() }) }
                    .size(thumbWdp, 56.dp)
                    .glassSurface(RoundedCornerShape(50))
            )
        }
        Row(Modifier.fillMaxSize().padding(BarPad)) {
            labels.forEachIndexed { i, label ->
                val active = 1f - abs(state.progress.value - i).coerceIn(0f, 1f)
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) {
                    Text(
                        label,
                        fontSize = 17.sp,
                        fontWeight = if (active > 0.5f) FontWeight.SemiBold else FontWeight.Medium,
                        color = ink().copy(alpha = 0.55f + 0.45f * active),
                    )
                }
            }
        }
    }
}
