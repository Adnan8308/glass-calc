package com.example.glasscalc

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.math.BigDecimal
import java.math.MathContext

data class HistoryItem(val expr: String, val result: String)

class CalcState {
    var expr by mutableStateOf("")
        private set
    var result by mutableStateOf("")
        private set
    val history = mutableStateListOf<HistoryItem>()
    private var done = false

    private val ops = "+−×÷"

    fun input(key: String) {
        when (key) {
            "AC" -> { expr = ""; result = ""; done = false }
            "⌫" -> {
                if (done) { expr = ""; result = ""; done = false } else {
                    expr = expr.dropLast(1); preview()
                }
            }
            "=" -> equals()
            "+", "−", "×", "÷" -> operator(key[0])
            "." -> dot()
            "%" -> {
                if (expr.isNotEmpty() && (expr.last().isDigit() || expr.last() == '%')) {
                    if (done) done = false
                    expr += "%"; preview()
                }
            }
            else -> digit(key)
        }
    }

    private fun digit(d: String) {
        if (done) { expr = ""; done = false }
        if (expr.endsWith("%")) return
        expr += d
        preview()
    }

    private fun dot() {
        if (done) { expr = ""; done = false }
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (seg.contains('.')) return
        if (seg.isEmpty()) expr += "0"
        expr += "."
        preview()
    }

    private fun operator(op: Char) {
        if (done) { expr = result; done = false }
        if (expr.isEmpty()) {
            if (op == '−') expr = "−"
            return
        }
        if (expr == "−") return
        val last = expr.last()
        if (last in ops) {
            val onlyOne = expr.length < 2 || expr[expr.length - 2] !in ops
            if (op == '−' && last in "×÷" && onlyOne) {
                expr += op
            } else {
                expr = expr.trimEnd { it in ops } + op
            }
        } else {
            expr += op
        }
        preview()
    }

    private fun preview() {
        val v = Evaluator.eval(expr)
        result = if (v == null) "" else Evaluator.format(v)
    }

    private fun equals() {
        if (expr.isEmpty() || done) return
        val v = try { Evaluator.evalOrThrow(expr) } catch (e: ArithmeticException) {
            result = "Can't divide by 0"; return
        } catch (e: Exception) { return }
        val r = Evaluator.format(v)
        history.add(0, HistoryItem(expr, r))
        result = r
        done = true
    }

    fun load(value: String) { expr = value; result = value; done = false }
    fun clearHistory() = history.clear()
}

object Evaluator {
    private const val OPS = "+−×÷"

    fun eval(src: String): Double? = try { evalOrThrow(src) } catch (e: Exception) { null }

    fun evalOrThrow(src: String): Double {
        val s = src.trimEnd { it in OPS }
        if (s.isEmpty()) throw IllegalArgumentException()
        val p = Parser(s)
        val v = p.expr()
        if (p.i != s.length) throw IllegalArgumentException()
        if (v.isNaN() || v.isInfinite()) throw ArithmeticException()
        return v
    }

    fun format(v: Double): String {
        if (v == Math.floor(v) && Math.abs(v) < 1e15) return v.toLong().toString().replace('-', '−')
        val s = BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        return s.replace('-', '−')
    }

    private class Parser(val s: String) {
        var i = 0
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '−')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '×' || s[i] == '÷')) {
                val op = s[i++]
                val r = factor()
                if (op == '÷') {
                    if (r == 0.0) throw ArithmeticException()
                    v /= r
                } else v *= r
            }
            return v
        }
        fun factor(): Double {
            var neg = false
            if (i < s.length && s[i] == '−') { neg = true; i++ }
            var v = number()
            while (i < s.length && s[i] == '%') { v /= 100.0; i++ }
            return if (neg) -v else v
        }
        fun number(): Double {
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException()
            return s.substring(st, i).toDouble()
        }
    }
}
